package utilities;

public class EndPoints {
    public static final String USER_ENDPOINT = "users";
}
