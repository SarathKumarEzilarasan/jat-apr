package models;

import java.util.ArrayList;
public class Root{
    public String id;
    public String type;
    public String name;
    public double ppu;
    public Batters batters;
    public ArrayList<Topping> topping;
}
