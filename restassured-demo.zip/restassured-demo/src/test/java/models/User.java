package models;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

// POJO -> Plain Old Java Object
public class User {
    private int id;
    private String name;
    private String email;
    private String status;
    private String gender;
}
