package models;
public class Batter{
    public String id;
    public String type;
}
