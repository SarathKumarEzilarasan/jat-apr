package models;
public class Topping{
    public String id;
    public String type;
}
