package models;

import java.util.ArrayList;
public class Batters{
    public ArrayList<Batter> batter;
}
