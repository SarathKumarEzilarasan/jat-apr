package tests;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.response.Response;
import models.User;
import org.testng.Assert;
import org.testng.annotations.Test;
import utilities.EndPoints;

import static io.restassured.RestAssured.given;

public class GoRestTests extends BaseTest {

    @Test
    public void getAllUsers() {
        //given -> pre-req
        //when  -> actions
        //then  -> results
        Response response = get(EndPoints.USER_ENDPOINT);
        System.out.println(response.body().asString());
        Assert.assertEquals(response.getStatusCode(), 200);
    }

    @Test
    public void createUser() throws JsonProcessingException {
//        String reqBody = "{\"name\":\"Tenali Ramakrishna\", \"gender\":\"male\", \"email\":\"22222tenali.ramakrishna@15ce.com\", \"status\":\"active\"}";

        User user = User.builder().name("john")
                .gender("male").email("john_test" + System.currentTimeMillis() + "@gmail.com")
                .status("active").build();
        User responseUser = createUserGetUserId(user);
        Assert.assertEquals(responseUser.getName(), user.getName());
        Assert.assertEquals(responseUser.getStatus(), user.getStatus());
    }

    @Test
    public void updateUser() throws JsonProcessingException {
        User user = User.builder().name("john doe")
                .gender("male").email("john_test" + System.currentTimeMillis() + "@gmail.com")
                .status("active").build();
        int userId = createUserGetUserId(user).getId();
        Response response = patch(EndPoints.USER_ENDPOINT + "/" + userId, user);
        User responseUser = objectMapper.readValue(response.body().asString(), User.class);
        Assert.assertEquals(response.getStatusCode(), 200);
        Assert.assertEquals(responseUser.getName(), user.getName());
    }

    public User createUserGetUserId(User req) throws JsonProcessingException {
        Response response = post(EndPoints.USER_ENDPOINT, req);
        User responseUser = objectMapper.readValue(response.body().asString(), User.class);
        return responseUser;
    }

}