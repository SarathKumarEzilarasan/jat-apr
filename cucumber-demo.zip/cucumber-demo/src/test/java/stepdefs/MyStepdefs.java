package stepdefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.LoginPage;
import utilities.ClickUtils;
import utilities.WaitUtils;

public class MyStepdefs {
    WebDriver driver;
    LoginPage loginPage;
    ClickUtils clickUtils;
    WaitUtils waitUtils;

    @Given("a browser is opened")
    public void aBrowserIsOpened() {
        driver = new ChromeDriver();
    }

    @Given("navigate to the login page")
    public void navigateToTheLoginPage() {
        driver.get("https://rahulshettyacademy.com/loginpagePractise/");
    }

    @When("user enters {string} and {string}")
    public void userEntersUsernameAndPassword(String username, String password) {
        loginPage = new LoginPage(driver);
        loginPage.username.sendKeys(username);
        loginPage.password.sendKeys(password);
    }

    @And("user clicks login button")
    public void userClicksLoginButton() {
        clickUtils = new ClickUtils(driver);
        waitUtils = new WaitUtils(driver);
        clickUtils.click(loginPage.signInBtn);
        waitUtils.waitForVisibility(loginPage.checkOutBtn);
    }

    @Then("home page should be displayed")
    public void homePageShouldBeDisplayed() {
        Assert.assertEquals("https://rahulshettyacademy.com/angularpractice/shop"
                , driver.getCurrentUrl());
    }


}
