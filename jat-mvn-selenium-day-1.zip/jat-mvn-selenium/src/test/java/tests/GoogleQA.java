package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class GoogleQA extends BaseTest{

    @Test
    public void test1() {
        chromeDriver.get("https://www.google.com");
        // locators -> using the attributes -> id
        By by = By.id("APjFqb");
        WebElement element = chromeDriver.findElement(by);
        element.sendKeys("mobiles");
        element.sendKeys(Keys.ENTER);
        //assertion -> comparing the expected result with actual result
        String results = chromeDriver.getPageSource(); // sdkjfsdkjfhkdsjf mobiles
        boolean result = results.contains("mobiles");
        Assert.assertEquals(result, true);
    }

    @Test
    public void test2() {
        chromeDriver.get("https://www.google.com");
        // locators -> using the attributes -> id
        By by = By.id("APjFqb");
        WebElement element = chromeDriver.findElement(by);
        element.sendKeys("mobiles");
        element.sendKeys(Keys.ENTER);
        //assertion -> comparing the expected result with actual result
        String results = chromeDriver.getPageSource(); // sdkjfsdkjfhkdsjf mobiles
        boolean result = results.contains("mobiles");
        Assert.assertEquals(result, true);
    }
}
