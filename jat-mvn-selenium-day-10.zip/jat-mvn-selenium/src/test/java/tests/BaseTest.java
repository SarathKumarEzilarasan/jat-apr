package tests;

import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.*;
import pages.ButtonPage;
import pages.TextBoxPage;
import utilities.*;

import java.time.Duration;

public class BaseTest {
    WebDriver driver;
    TextBoxPage textBoxPage;
    ButtonPage buttonPage;
    String url;
    String browser;
    ClickUtils clickUtils;
    WaitUtils waitUtils;
    ElementUtils elementUtils;

    @BeforeMethod
    @Parameters("browser")
    public void setUp(String browser) {
        QaEnvProps.init();
        TestDataReader.init();
        TestDataJsonReader.init();
        url = QaEnvProps.getProperty("url");
//        browser = QaEnvProps.getProperty("browser");
        this.browser = browser;
        if (browser.equals("chrome")) {
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--headless");
            driver = new ChromeDriver(options);
        } else {
            FirefoxOptions options = new FirefoxOptions();
            options.addArguments("--headless");
            driver = new FirefoxDriver(options);
        }
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        textBoxPage = new TextBoxPage(driver);
        buttonPage = new ButtonPage(driver);
        clickUtils = new ClickUtils(driver);
        waitUtils = new WaitUtils(driver);
        elementUtils = new ElementUtils(driver);
    }

    //@AfterTest
    public void tearDown() {
        driver.quit();
    }


}
