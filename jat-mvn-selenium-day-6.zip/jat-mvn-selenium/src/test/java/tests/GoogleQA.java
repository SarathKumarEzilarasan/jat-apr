package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

public class GoogleQA extends BaseTest {

    @Test
    public void test1() {
        chromeDriver.get("https://www.google.com");
        // locators -> using the attributes -> id
        By by = By.xpath("//a[@class='gb_I']");
        WebElement element = chromeDriver.findElement(by);
        element.click();
//        element.sendKeys("mobiles");
//        element.sendKeys(Keys.TAB);
//        //assertion -> comparing the expected result with actual result
//        String results = chromeDriver.getPageSource(); // sdkjfsdkjfhkdsjf mobiles
//        boolean result = results.contains("mobiles");
//        Assert.assertEquals(result, true);
    }

    @Test
    public void test2() {
        chromeDriver.get("https://en.wikipedia.org/wiki/Artificial_intelligence#History");
//        firefoxDriver.navigate().to("https://www.google.com");
//        By by = By.xpath("//a[@href='#History']");
        String text = chromeDriver.findElement(By.xpath("//a[@href='#History']")).getAttribute("class");
        System.out.println(text);
    }

    @Test
    public void test3() {
        chromeDriver.get("https://www.amazon.in/");
//        By by = By.xpath("//div[@id=\"nav-xshop\"]//a[contains(@class,\"nav-a\")]");
        List<WebElement> tabs = chromeDriver
                .findElements(By.xpath("//div[@id=\"nav-xshop\"]//a[contains(@class,\"nav-a\")]"));
        System.out.println(tabs.size());
    }

    @Test
    public void textBox() {
        chromeDriver.get("https://www.leafground.com/input.xhtml");
        String status = chromeDriver.findElement(By.id("j_idt88:j_idt97")).getAttribute("value");
        Assert.assertEquals(status, "My learning is superb so far.");
        chromeDriver.findElement(By.id("j_idt106:thisform:age")).sendKeys(Keys.ENTER);
        String errorMessage = chromeDriver.findElement(By.id("j_idt106:thisform:j_idt110_error-detail")).getText();
        Assert.assertEquals(errorMessage, "Age is mandatory");
        Point initialPoint = chromeDriver.findElement(By.id("j_idt106:j_idt113")).getLocation();
        chromeDriver.findElement(By.id("j_idt106:float-input")).click();
        Point finalPoint = chromeDriver.findElement(By.id("j_idt106:j_idt113")).getLocation();
//        Assert.assertNotEquals(initialPoint.getX(), finalPoint.getX());
//        Assert.assertNotEquals(initialPoint.getY(), finalPoint.getY());
    }

    @Test
    public void button() throws InterruptedException {
        chromeDriver.get("https://www.leafground.com/button.xhtml");
        //assert for the title
        //assert for isEnabled
        //getLocation
        Dimension dimension = chromeDriver.findElement(By.id("j_idt88:j_idt98")).getSize();
        Assert.assertEquals(dimension.getHeight(), 34);
        Assert.assertEquals(dimension.getWidth(), 87);
        chromeDriver.findElement(By.id("j_idt88:j_idt102:imageBtn")).click();
        Thread.sleep(2000);
        chromeDriver.findElement(By.id("j_idt88:j_idt102:imageBtn")).click();
        Thread.sleep(2000);
        chromeDriver.findElement(By.id("j_idt88:j_idt107")).click();
        List<WebElement> buttons = chromeDriver
                .findElements(By.xpath("(//div[@class=\"card\"])[7]//button"));
        System.out.println(buttons.size());
        Assert.assertEquals(buttons.size(), 4);
    }

    @Test
    public void dropDown() throws InterruptedException {
        chromeDriver.get("https://www.leafground.com/select.xhtml");
        WebElement dropDownEle = chromeDriver
                .findElement(By.xpath("//select[@class=\"ui-selectonemenu\"]"));
        Select dropDown1 = new Select(dropDownEle);
        dropDown1.selectByVisibleText("Cypress");
        List<WebElement> options = dropDown1.getOptions();
        for (WebElement element : options) {
            System.out.println(element.getText());
        }

        chromeDriver.findElement(By.id("j_idt87:country")).click();
        chromeDriver.findElement(By.id("j_idt87:country_3")).click();
        Thread.sleep(2000);
        chromeDriver.findElement(By.id("j_idt87:city")).click();
        Thread.sleep(2000);
        //ul[@id="j_idt87:city_items"]//li ----- //li[contains(@id,"j_idt87:city_")]
        List<WebElement> cities = chromeDriver
                .findElements(By.xpath("//ul[@id=\"j_idt87:city_items\"]//li"));
        List<String> expectedCities = Arrays.asList("Bengaluru", "Chennai", "Delhi");
        for (int i = 1; i < cities.size(); i++) {
            Assert.assertEquals(cities.get(i).getText(), expectedCities.get(i - 1));
        }
    }


    @Test
    public void test5() {
        chromeDriver.get("https://www.leafground.com/select.xhtml");
        WebElement element = chromeDriver.findElement(By.id("j_idt87:country"));
        chromeDriver.navigate().refresh();
        element = chromeDriver.findElement(By.id("j_idt87:country"));
        element.click();

    }

    @Test
    public void checkBox() throws InterruptedException {
        chromeDriver.get("https://www.leafground.com/checkbox.xhtml");
        List<WebElement> checkBoxes = chromeDriver.findElements(
                By.xpath("//div[@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default']"));
        checkBoxes.get(1).click();
        Thread.sleep(2000);
        String str = chromeDriver.findElement(By.xpath("//div[@class=\"ui-growl-message\"]")).getText();
        Assert.assertEquals(str, "Checked");
        checkBoxes.get(1).click();
        Thread.sleep(2000);
        str = chromeDriver.findElement(By.xpath("//div[@class=\"ui-growl-message\"]")).getText();
        Assert.assertEquals(str, "Unchecked");

        String favLang = "Javascript";
        //table[@id="j_idt87:basic"]//label

        List<WebElement> langCheckBoxes = chromeDriver.findElements(By.xpath("//table[@id=\"j_idt87:basic\"]//div[@class=\"ui-chkbox-box ui-widget ui-corner-all ui-state-default\"]"));
        List<WebElement> labels = chromeDriver
                .findElements(By.xpath("//label[contains(@for,\"j_idt87:basic\")]"));


        for (int i = 0; i < labels.size(); i++) {
            String text = labels.get(i).getText();
            if (text.equals(favLang)) {
                langCheckBoxes.get(i).click();
                break;
            }
        }


    }

    @Test
    public void radioButton() {
        chromeDriver.get("https://www.leafground.com/radio.xhtml");
        List<WebElement> radioButtons = chromeDriver.findElements(By.xpath("//table[@id=\"j_idt87:console2\"]//div[contains(@class,\"ui-radiobutton-box\")]"));
        List<WebElement> labels = chromeDriver.findElements(By.xpath("//table[@id=\"j_idt87:console2\"]//label"));

        for (int i = 0; i < radioButtons.size(); i++) {
            boolean selected = radioButtons.get(i).isSelected();
            if (selected == true) {
                System.out.println(labels.get(i).getText());
            }
        }

        int age = 55;
        List<WebElement> ageLabels = chromeDriver.findElements(By.xpath("//label[contains(@for,\"j_idt87:age:\")]"));
        List<WebElement> ageRadioButtons = chromeDriver.findElements(By.xpath("//div[@id=\"j_idt87:age\"]//div[contains(@class,\"ui-radiobutton-box ui-widget ui-corner-all\")]"));

        for (int i = 0; i < ageLabels.size(); i++) {
            String ageGroup = ageLabels.get(i).getText(); // 21-40 Years
            ageGroup = ageGroup.replace(" Years", ""); // 21-40
            String[] ages = ageGroup.split("-"); // 21 40
            int minAge = Integer.parseInt(ages[0]);
            int maxAge = Integer.parseInt(ages[1]);
            if (age >= minAge && age <= maxAge) {
                ageRadioButtons.get(i).click();
            }
        }
    }


    @Test
    public void waits() throws InterruptedException {
        chromeDriver.get("https://www.leafground.com/waits.xhtml");
        chromeDriver.findElement(By.id("j_idt87:j_idt89")).click();
//        WebDriverWait wait = new WebDriverWait(chromeDriver, Duration.ofSeconds(20));

        Wait wait = new FluentWait(chromeDriver)
                .withTimeout(Duration.ofSeconds(20))
                .pollingEvery(Duration.ofSeconds(5))
                .ignoring(NoSuchElementException.class);
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("j_idt87:j_idt90")));
//
//        boolean display = chromeDriver.findElement(By.id("j_idt87:j_idt90")).isDisplayed();
//        System.out.println(display);
//        chromeDriver.findElement(By.id("j_idt87:j_idt92")).click();
//        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("j_idt87:j_idt93")));
        chromeDriver.findElement(By.id("j_idt87:j_idt95")).click();
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class=\"ui-growl-message\"]")));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("j_idt87:j_idt96")));
        chromeDriver.findElement(By.id("j_idt87:j_idt96")).click();
    }

    @Test
    public void table() throws InterruptedException {
        chromeDriver.get("https://www.leafground.com/table.xhtml");
        chromeDriver.findElement(By.id("form:j_idt89:globalFilter")).sendKeys("India");


        WebDriverWait wait = new WebDriverWait(chromeDriver, Duration.ofSeconds(20));// 0-20
        wait.until(ExpectedConditions.stalenessOf(chromeDriver
                .findElement(By.xpath("//tbody[@id=\"form:j_idt89_data\"]//tr"))));


        Thread.sleep(2000);

        List<WebElement> rows = chromeDriver
                .findElements(By.xpath("//tbody[@id=\"form:j_idt89_data\"]//tr"));
        for (WebElement row : rows) {
            List<WebElement> cols = row.findElements(By.tagName("td"));
            for (WebElement col : cols) {
                System.out.print(col.getText() + " ");
            }
            System.out.println();
        }
    }

    @Test
    public void file() {
        chromeDriver.get("https://www.leafground.com/file.xhtml");
        chromeDriver.findElement(By.id("j_idt88:j_idt89_input")).sendKeys("/Users/preethir/Downloads/RestAssured.xlsx");
    }

    @Test
    public void mouseActions() {
//        chromeDriver.get("https://www.leafground.com/drag.xhtml");
//        WebElement element = chromeDriver.findElement(By.xpath("//div[@id='form:conpnl']"));
        Actions actions = new Actions(chromeDriver);
//        actions.dragAndDropBy(element, 100, 200).perform();
//        WebElement source = chromeDriver.findElement(By.id("form:drag_content"));
//        WebElement target = chromeDriver.findElement(By.id("form:drop"));
//        actions.dragAndDrop(source,target).perform();
//        WebElement header = chromeDriver.findElement(By.xpath("//div[@class=\"card\"]//h4"));
//        actions.contextClick(header).perform();
        chromeDriver.get("https://www.snapdeal.com/");
        WebElement signIn = chromeDriver.findElement(By.cssSelector("div[class=\"accountInner\"]"));
        actions.moveToElement(signIn).keyUp(Keys.CONTROL).perform();
        boolean display = chromeDriver.findElement(By.xpath("//a[@href=\"https://www.snapdeal.com/myorders\"]")).isDisplayed();
        Assert.assertTrue(display);
    }

    @Test
    public void alerts() {
        chromeDriver.get("https://www.leafground.com/alert.xhtml");
        chromeDriver.findElement(By.id("j_idt88:j_idt93")).click();
        chromeDriver.switchTo().alert().accept();
//        chromeDriver.switchTo().alert().dismiss();
        String result = chromeDriver.findElement(By.id("result")).getText();
        Assert.assertEquals(result, "User Clicked : OK");
        chromeDriver.findElement(By.id("j_idt88:j_idt104")).click();
        chromeDriver.switchTo().alert().sendKeys("hello world");
        chromeDriver.switchTo().alert().accept();
    }

    @Test
    public void frames() {
        chromeDriver.get("https://www.leafground.com/frame.xhtml");
        WebElement iframe = chromeDriver.findElement(By.xpath("//iframe[@src=\"default.xhtml\"]"));
        chromeDriver.switchTo().frame(iframe);
        chromeDriver.findElement(By.id("Click")).click();
        chromeDriver.switchTo().parentFrame();
        String str = chromeDriver.findElement(By.xpath("//form[@id=\"j_idt88\"]//h5")).getText();
        System.out.println(str);
        WebElement childFrame = chromeDriver.findElement(By.xpath("//iframe[@src=\"page.xhtml\"]"));
        chromeDriver.switchTo().frame(childFrame);
        WebElement grandChildFrame = chromeDriver.findElement(By.xpath("//iframe[@src=\"framebutton.xhtml\"]"));
        chromeDriver.switchTo().frame(grandChildFrame);
        chromeDriver.findElement(By.id("Click")).click();
        chromeDriver.switchTo().parentFrame();
        chromeDriver.switchTo().parentFrame();
        str = chromeDriver.findElement(By.xpath("//form[@id=\"j_idt88\"]//h5")).getText();
        System.out.println(str);
    }

    @Test
    public void windows() {
        chromeDriver.get("https://www.leafground.com/window.xhtml");
        chromeDriver.findElement(By.id("j_idt88:new")).click();
        Set<String> windows = chromeDriver.getWindowHandles();
        List<String> windowList = new ArrayList<>(windows);
        chromeDriver.switchTo().window(windowList.get(1));
        Assert.assertEquals(chromeDriver.getCurrentUrl(), "https://www.leafground.com/dashboard.xhtml");
//        chromeDriver.switchTo().defaultContent();
        chromeDriver.close();
        chromeDriver.switchTo().window(windowList.get(0));
        Assert.assertEquals(chromeDriver.getCurrentUrl(), "https://www.leafground.com/window.xhtml");
        WebDriverWait wait = new WebDriverWait(chromeDriver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.numberOfWindowsToBe(2));


        JavascriptExecutor javascriptExecutor = chromeDriver;
        List<WebElement> list = chromeDriver.findElements(By.xpath("//div[contains(@id,\"ember\") and @role=\"region\"]"));


        String post = "Happy BirthDay John";
        String friendName = "Peter";

        boolean flag = false;
        WebElement noMorePost = chromeDriver.findElement(By.xpath("//a"));


        javascriptExecutor.executeScript("arguments[0].click();", noMorePost);

        while (flag == false && noMorePost.isDisplayed() == false) {
            javascriptExecutor.executeScript("window.scrollTo(0, document.body.scrollHeight);");
            list = chromeDriver.findElements(By.xpath("//div[contains(@id,\"ember\") and @role=\"region\"]"));
            for (WebElement ele : list) {
                if (ele.getText().contains(post) && ele.getText().contains(friendName)) {
                    System.out.println("found the post");
                    flag = true;
                    break;
                }
            }
        }
    }
}

// FB -> find a post which was made last year .... Given -> friend name and the post content

// JavascriptExecutor
// //div[contains(@id,"ember") and @role="region"]

//

