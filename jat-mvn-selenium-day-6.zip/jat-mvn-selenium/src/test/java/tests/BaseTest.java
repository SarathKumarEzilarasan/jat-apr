package tests;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class BaseTest {
    ChromeDriver chromeDriver;
//    FirefoxDriver firefoxDriver;

    @BeforeTest
    public void setUp() {
        chromeDriver = new ChromeDriver();
//        firefoxDriver = new FirefoxDriver();
        chromeDriver.manage().window().maximize();
        chromeDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
    }

    //@AfterTest
    public void tearDown() {
        chromeDriver.quit();
    }

}
