package tests;

import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import pages.ButtonPage;
import pages.TextBoxPage;
import utilities.*;

import java.time.Duration;

public class BaseTest {
    WebDriver driver;
    TextBoxPage textBoxPage;
    ButtonPage buttonPage;
    String url;
    String browser;
    ClickUtils clickUtils;
    WaitUtils waitUtils;
    ElementUtils elementUtils;


    @BeforeTest
    public void setUp() {
        QaEnvProps.init();
        TestDataReader.init();
        TestDataJsonReader.init();
        url = QaEnvProps.getProperty("url");
        browser = QaEnvProps.getProperty("browser");
        if (browser.equals("chrome")) {
            driver = new ChromeDriver();
        } else {
            driver = new FirefoxDriver();
        }
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        textBoxPage = new TextBoxPage(driver);
        buttonPage = new ButtonPage(driver);
        clickUtils = new ClickUtils(driver);
        waitUtils = new WaitUtils(driver);
        elementUtils = new ElementUtils(driver);
    }

    //@AfterTest
    public void tearDown() {
        driver.quit();
    }




}
