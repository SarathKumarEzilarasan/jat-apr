package tests;

import org.testng.annotations.*;

public class Test {

    @BeforeSuite
    public void beforeSuite() {
        System.out.println("before suite");
    }

    @BeforeTest
    public void setup() {
        System.out.println("before test");
    }

    @BeforeClass
    public void beforeClass() {
        System.out.println("before class");
    }

    @org.testng.annotations.Test()
    public void z() throws Exception {
        System.out.println("from test case");
    }

    @AfterClass
    public void afterClass() {
        System.out.println("after class");
    }

    @AfterTest
    public void teardown() {
        System.out.println("after test");
    }

    @AfterSuite
    public void afterSuite() {
        System.out.println("after suite");
    }
}
