package utilities;

public class Constants {
    public static final String INPUT_URL = "/input.xhtml";
    public static final String BUTTON_URL = "/button.xhtml";
}
