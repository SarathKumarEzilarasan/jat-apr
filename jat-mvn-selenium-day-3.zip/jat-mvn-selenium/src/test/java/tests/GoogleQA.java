package tests;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

public class GoogleQA extends BaseTest {

    @Test
    public void test1() {
        chromeDriver.get("https://www.google.com");
        // locators -> using the attributes -> id
        By by = By.xpath("//a[@class='gb_I']");
        WebElement element = chromeDriver.findElement(by);
        element.click();
//        element.sendKeys("mobiles");
//        element.sendKeys(Keys.TAB);
//        //assertion -> comparing the expected result with actual result
//        String results = chromeDriver.getPageSource(); // sdkjfsdkjfhkdsjf mobiles
//        boolean result = results.contains("mobiles");
//        Assert.assertEquals(result, true);
    }

    @Test
    public void test2() {
        chromeDriver.get("https://en.wikipedia.org/wiki/Artificial_intelligence#History");
//        firefoxDriver.navigate().to("https://www.google.com");
//        By by = By.xpath("//a[@href='#History']");
        String text = chromeDriver.findElement(By.xpath("//a[@href='#History']")).getAttribute("class");
        System.out.println(text);
    }

    @Test
    public void test3() {
        chromeDriver.get("https://www.amazon.in/");
//        By by = By.xpath("//div[@id=\"nav-xshop\"]//a[contains(@class,\"nav-a\")]");
        List<WebElement> tabs = chromeDriver
                .findElements(By.xpath("//div[@id=\"nav-xshop\"]//a[contains(@class,\"nav-a\")]"));
        System.out.println(tabs.size());
    }

    @Test
    public void textBox() {
        chromeDriver.get("https://www.leafground.com/input.xhtml");
        String status = chromeDriver.findElement(By.id("j_idt88:j_idt97")).getAttribute("value");
        Assert.assertEquals(status, "My learning is superb so far.");
        chromeDriver.findElement(By.id("j_idt106:thisform:age")).sendKeys(Keys.ENTER);
        String errorMessage = chromeDriver.findElement(By.id("j_idt106:thisform:j_idt110_error-detail")).getText();
        Assert.assertEquals(errorMessage, "Age is mandatory");
        Point initialPoint = chromeDriver.findElement(By.id("j_idt106:j_idt113")).getLocation();
        chromeDriver.findElement(By.id("j_idt106:float-input")).click();
        Point finalPoint = chromeDriver.findElement(By.id("j_idt106:j_idt113")).getLocation();
//        Assert.assertNotEquals(initialPoint.getX(), finalPoint.getX());
//        Assert.assertNotEquals(initialPoint.getY(), finalPoint.getY());
    }

    @Test
    public void button() throws InterruptedException {
        chromeDriver.get("https://www.leafground.com/button.xhtml");
        //assert for the title
        //assert for isEnabled
        //getLocation
        Dimension dimension = chromeDriver.findElement(By.id("j_idt88:j_idt98")).getSize();
        Assert.assertEquals(dimension.getHeight(), 34);
        Assert.assertEquals(dimension.getWidth(), 87);
        chromeDriver.findElement(By.id("j_idt88:j_idt102:imageBtn")).click();
        Thread.sleep(2000);
        chromeDriver.findElement(By.id("j_idt88:j_idt102:imageBtn")).click();
        Thread.sleep(2000);
        chromeDriver.findElement(By.id("j_idt88:j_idt107")).click();
        List<WebElement> buttons = chromeDriver
                .findElements(By.xpath("(//div[@class=\"card\"])[7]//button"));
        System.out.println(buttons.size());
        Assert.assertEquals(buttons.size(), 4);
    }

    @Test
    public void dropDown() throws InterruptedException {
        chromeDriver.get("https://www.leafground.com/select.xhtml");
        WebElement dropDownEle = chromeDriver
                .findElement(By.xpath("//select[@class=\"ui-selectonemenu\"]"));
        Select dropDown1 = new Select(dropDownEle);
        dropDown1.selectByVisibleText("Cypress");
        List<WebElement> options = dropDown1.getOptions();
        for (WebElement element : options) {
            System.out.println(element.getText());
        }

        chromeDriver.findElement(By.id("j_idt87:country")).click();
        chromeDriver.findElement(By.id("j_idt87:country_3")).click();
        Thread.sleep(2000);
        chromeDriver.findElement(By.id("j_idt87:city")).click();
        Thread.sleep(2000);
        //ul[@id="j_idt87:city_items"]//li ----- //li[contains(@id,"j_idt87:city_")]
        List<WebElement> cities = chromeDriver
                .findElements(By.xpath("//ul[@id=\"j_idt87:city_items\"]//li"));
        List<String> expectedCities = Arrays.asList("Bengaluru", "Chennai", "Delhi");

        for (int i = 1; i < cities.size(); i++) {
            Assert.assertEquals(cities.get(i).getText(), expectedCities.get(i - 1));
        }



    }


    @Test
    public void test5() {
        chromeDriver.get("https://www.leafground.com/select.xhtml");
        WebElement element = chromeDriver.findElement(By.id("j_idt87:country"));
        chromeDriver.navigate().refresh();
        element = chromeDriver.findElement(By.id("j_idt87:country"));
        element.click();

    }
}
