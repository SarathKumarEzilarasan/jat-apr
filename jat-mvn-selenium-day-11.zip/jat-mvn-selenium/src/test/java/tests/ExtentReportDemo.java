package tests;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import utilities.TestNgListener;

public class ExtentReportDemo extends BaseTest {

    ExtentTest extentTest;

    @BeforeTest
    public void startReport() {

    }

    @Test
    public void test() {
        extentTest = TestNgListener.getExtentReports().createTest("Verify the payment for UPI");
        driver.get("https://www.google.com");
        String path = BaseTest.takeScreenShot("test");
        extentTest.fail("Payment is successful" + extentTest.addScreenCaptureFromPath(path));
    }

    @AfterTest
    public void endReport() {

    }
}
