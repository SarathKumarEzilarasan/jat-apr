package tests;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import pages.ButtonPage;
import pages.TextBoxPage;
import utilities.QaEnvProps;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class BaseTest {
    ChromeDriver chromeDriver;
    //    FirefoxDriver firefoxDriver;
    TextBoxPage textBoxPage;
    ButtonPage buttonPage;
    String url;

    @BeforeTest
    public void setUp() {
        chromeDriver = new ChromeDriver();
//        firefoxDriver = new FirefoxDriver();
        chromeDriver.manage().window().maximize();
        chromeDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        textBoxPage = new TextBoxPage(chromeDriver);
        buttonPage = new ButtonPage(chromeDriver);
        QaEnvProps.init();
        url = QaEnvProps.getProperty("url");
    }

    //@AfterTest
    public void tearDown() {
        chromeDriver.quit();
    }

}
