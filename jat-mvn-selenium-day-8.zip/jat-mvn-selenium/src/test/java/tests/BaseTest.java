package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import pages.ButtonPage;
import pages.TextBoxPage;
import utilities.QaEnvProps;
import utilities.TestDataJsonReader;
import utilities.TestDataReader;

import java.time.Duration;

public class BaseTest {
    WebDriver driver;
    TextBoxPage textBoxPage;
    ButtonPage buttonPage;
    String url;
    String browser;


    @BeforeTest
    public void setUp() {
        QaEnvProps.init();
        TestDataReader.init();
        TestDataJsonReader.init();
        url = QaEnvProps.getProperty("url");
        browser = QaEnvProps.getProperty("browser");
        if (browser.equals("chrome")){
            driver = new ChromeDriver();
        }else {
            driver = new FirefoxDriver();
        }
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        textBoxPage = new TextBoxPage(driver);
        buttonPage = new ButtonPage(driver);

    }

    //@AfterTest
    public void tearDown() {
        driver.quit();
    }

}
